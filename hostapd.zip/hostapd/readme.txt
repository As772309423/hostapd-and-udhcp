make CC=arm-hisiv300-linux-gcc
